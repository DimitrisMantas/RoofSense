from startinpy.startinpy import *
from startinpy import startinpy as _sp
__doc__ = _sp.__doc__
